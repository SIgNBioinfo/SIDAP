cytof_nonlinear <-
function(data, baseName = NULL, distMethod = "euclidean", 
    method = "isomap", lle_k = 12, lle_m = 2, isomap_k = 5, isomap_ndim = NULL, 
    isomapFragmentOK = FALSE) {
    if (is.null(isomap_ndim)) {
        isomap_ndim <- dim(data)[2]
    }
    if (method == "pca") {
        pca <- prcomp(data, scale = TRUE)
        pdf(paste(baseName, "pca_variance.pdf", sep = ""), width = 20, 
            height = 20)
        plot(pca, main = "Explained variance of principle components")
        dev.off()
        pdf(paste(baseName, "pca.pdf", sep = ""), width = 20, height = 20)
        plot(pca$x[, 1], pca$x[, 2], main = "sample PCA")
        dev.off()
        write.table(pca$x, paste(baseName, "pca_pc.txt", sep = ""), sep = "\t")
        colnames(pca$x) <- paste("PCA_dim", c(1:ncol(pca$x)), sep = "")
        return(pca$x)
    }
    if (method == "lle") {
        if (!require(lle)) {
            SIDAP_LoadPackageMsg()
        }
        
        # lle_k <- calc_k(data, 2, kmin=1, kmax=20, plotres=TRUE,
        # parallel=TRUE, cpus=10, iLLE=FALSE)
        results <- lle(X = data, m = lle_m, k = lle_k, reg = 2, ss = FALSE, 
            id = TRUE, v = 0.9)
        png("lle.png")
        split.screen(c(2, 1))
        screen(1)
        plot(results$Y, main = "embedded data", xlab = expression(y[1]), 
            ylab = expression(y[2]))
        screen(2)
        plot(results$id, main = "intrinsic dimension", type = "l", xlab = expression(x[i]), 
            ylab = "id", lwd = 2)
        dev.off()
        write.table(results$Y, "lle_y.txt", sep = "\t")
        write.table(results$id, "lle_id.txt", sep = "\t")
    }
    if (method == "isomap") {
        if (!require(vegan)) {
            SIDAP_LoadPackageMsg()
        }
        
        dis <- vegdist(data, method = distMethod)
        tr <- spantree(dis)
        ord <- isomap(dis, ndim = isomap_ndim, k = isomap_k, fragmentedOK = isomapFragmentOK)
        save(dis, tr, ord, file = paste(baseName, distMethod, isomap_k, 
            "isomap.RData", sep = ""))
        
        colnames(ord$points) <- paste("ISOMAP_dim", c(1:isomap_ndim), 
            sep = "")
        write.table(ord$points, paste(baseName, "isomap.txt", sep = ""), 
            sep = "\t", col.names = NA)
        
        # png(paste(baseName,'isomap_red.png',sep=''),width=3500,height=2000)
        # pdf(paste(baseName,'isomap_red.pdf',sep=''),width=17.5,height=10)
        # pl <- plot(ord, main=paste('isomap k=',isomap_k,sep=''))
        # lines(tr,pl,col='red') dev.off()
        
        pdf(paste(baseName, distMethod, isomap_k, "isomap.pdf", sep = "_"), 
            width = 35, height = 20)
        # png(paste(baseName,distMethod,isomap_k,'isomap.png',sep='_'),width=3500,height=2000)
        pl <- plot(ord, main = paste("isomap k=", isomap_k, sep = ""))
        dev.off()
        
        return(ord$points)
    }
    if (method == "tsne") {
        initial_dims = dim(data)[2]
        perplexity = 30
        theta = 0.5
        
        curr_path = getwd()
        #### NOTE, DANGEROUS ERROR #########
        bh_tsne_path <- paste(path.package(package = "sidap"), "/bh_tsne", sep = "")
        setwd(bh_tsne_path)
        
        n <- nrow(data)
        d <- ncol(data)
        pca <- prcomp(data)
        
        to.write = file("data.dat", "wb")
        writeBin(n, to.write)
        writeBin(d, to.write)
        writeBin(theta, to.write)
        writeBin(perplexity, to.write)
        writeBin(c(t(pca$x)), to.write)
        close(to.write)
        
        if (.Platform$OS.type == "windows" & .Platform$r_arch == "x64") {
            system("./bh_tsne_win64")
        } else if (.Platform$OS.type == "windows" & .Platform$r_arch == 
            "i386") {
            system("./bh_tsne_win32")
        } else if (.Platform$OS.type == "unix") {
            system("./bh_tsne_linux64")
        } else {
            system("./bh_tsne_mac64")
        }
        
        to.read = file("result.dat", "rb")
        n <- readBin(to.read, "integer", 1)
        d <- readBin(to.read, "integer", 1)
        mapped <- readBin(to.read, "double", n * d)
        mapped <- matrix(mapped, nrow = n, ncol = d, byrow = TRUE)
        colnames(mapped) <- paste("ViSNE_dim", c(1:ncol(mapped)), sep = "")
        rownames(mapped) <- row.names(data)
        
        file.remove("data.dat")
        file.remove("result.dat")
        setwd(curr_path)
        
        pdf(paste(baseName, "visne.pdf", sep = "_"), width = 35, height = 20)
        plot(mapped[, 1], mapped[, 2], main = "ViSNE")
        dev.off()
        
        # write.table(mapped,'visne.txt')
        return(mapped)
    }
}
