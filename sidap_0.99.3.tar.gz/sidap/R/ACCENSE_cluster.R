ACCENSE_cluster <-
function(ydata, X, markers) {
    
    y_range_x <- max(ydata[, 1]) - min(ydata[, 1])
    y_range_y <- max(ydata[, 2]) - min(ydata[, 2])
    y_range <- min(c(y_range_x, y_range_y))
    
    # Find optimal kernel bandwidth
    num_band <- 20
    kernel_min <- y_range/100
    kernel_max <- y_range/10
    sig_tol_range <- seq(kernel_min, kernel_max, length = num_band)
    
    cat("Testing kernel bandwidth for ", num_band, "points in the range min= ", 
        kernel_min, " to max= ", kernel_max, "\n")
    cat("This will take a while...\n")
    Npeaks <- vector()
    
    for (i in 1:length(sig_tol_range)) {
        cat("Computing number of peaks for kernel bandwidth = ", sig_tol_range[i], 
            "\n")
        density_output <- DataDensityPlot(ydata, sig_tol_range[i])
        p <- PeakFind(density_output)
        Npeaks[i] <- dim(p)[1]
    }
    
    # Plot peaks
    peakdata <- data.frame(numpeaks = Npeaks, sig_range = sig_tol_range)
    p <- ggplot(peakdata, aes(x = sig_range, y = numpeaks)) + geom_line() + 
        geom_point()
    p <- p + xlab(expression(gamma)) + ylab("N_peaks")
    ggsave(filename = "Npeaks.pdf")
    graphics.off()
    
    
    # Locate plateau
    flag <- 0
    for (i in 1:length(sig_tol_range)) {
        if (i > 1) {
            if (Npeaks[i - 1] - Npeaks[i] <= 1) {
                sig_opt <- sig_tol_range[i - 1]
                Nsub <- Npeaks[i - 1]
                flag <- 1
                break
            }
        }
    }
    
    if (flag == 0) {
        cat("Error : Could not locate plateau in the Npeaks vs. sigma graph!\n")
        cat("Consider changing the search space. Increase 'num_band' or change 'kernel_min'/'kernel_max' in ACCENSE_cluster.r \n")
        input <- readline("Select one (y) - If you would like to proceed with a user-specified bandwidth,\n (n) - Exit and change bandwidth search parameters : ")
        
        if (input == "y") {
            sig_opt <- readline("Please specify the desired kernel bandwidth (Warning : This will directly determine # of subpopulations):")
            sig_opt <- as.numeric(sig_opt)
        }
    } else {
        
        cat("Based on plateau in Npeaks vs. gamma, the optimal kernel bandwidth selected is ", 
            sig_opt, " and ", Nsub, " populations are identified\n")
        reply <- readline("Do you want to overrule this and provide your own value of bandwidth? (y/n): ")
        
        if (reply == "y") {
            sig_opt <- readline("Please specify the desired kernel bandwidth (Warning : This will directly determine # of subpopulations):")
            sig_opt <- as.numeric(sig_opt)
        }
    }
    
    
    # Compute density map
    density_output <- DataDensityPlot(ydata, sig_opt)
    density_output
    
    # Find peaks
    p <- PeakFind(density_output)
    p
    
    
    
    # Number subpopulations plot.new() frame() image(f1, zlim = c(0,
    # 7e-5), xlab = expression(y[2]), ylab = expression(y[1]) ) for (i in
    # 1:dim(p)[1]){ text(p[,1],p[,2],labels = seq_along(p[,1])) }
    
    
    # Obtain subpopulation samples
    Subpop <- array(list(), dim(p)[1])
    ind_vector <- vector()
    cluster_vector <- vector()
    
    for (i in 1:dim(p)[1]) {
        
        # Find closest subpopulation and determine appropriate radius of 2-d
        # space to draw sample from
        dists <- (kronecker(matrix(1, dim(p)[1] - 1, 1), matrix(p[i, 
            ], 1, 2)) - p[-i, ])^2
        dists <- matrix(apply(dists, 1, sum), dim(p)[1] - 1, 1)
        
        min_dist <- sqrt(min(dists))
        
        dist2 <- ydata - kronecker(matrix(1, dim(ydata)[1], 1), matrix(p[i, 
            ], 1, 2))
        dist2 <- matrix(apply(dist2^2, 1, sum), dim(ydata)[1], 1)
        ind <- which(dist2 < (min_dist/2)^2)
        
        Subpop[[i]] <- list(X = X[ind, ], size = length(ind))  # Subpop[[i]]$X, Subpop[[i]]$size
        ind_vector <- c(ind_vector, row.names(ydata)[ind])
        cluster_vector <- c(cluster_vector, rep(i, length(ind)))
    }
    
    ind_cluster <- data.frame(ind = ind_vector, cluster = cluster_vector)
    return(list(density_output, Subpop, ind_cluster))
}
