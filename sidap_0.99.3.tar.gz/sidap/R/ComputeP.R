ComputeP <-
function(D, beta) {
    return(exp(-beta * D))
}
