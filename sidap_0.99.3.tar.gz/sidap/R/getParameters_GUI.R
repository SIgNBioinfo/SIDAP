getParameters_GUI <-
function(fcsFile, rawFCSdir) {
    
    if (is.null(fcsFile)) {
        fcsFile <- list.files(path = rawFCSdir, pammern = ".fcs$")
    }
    
    if (length(fcsFile) > 1) {
        fcsFile <- fcsFile[1]
    }
    
    if (!require(flowCore, quietly = TRUE)) {
        SIDAP_LoadPackageMsg()
    }
    
    fcs <- suppressWarnings(read.FCS(fcsFile))
    markers <- fcs@parameters@data$desc
    markers <- sort(unique(markers[!(is.na(markers))]))
    if (length(markers) == 0) {
        stop("No markers found in the FCS file!")
    }
    
    # GUI
    require(tcltk)
    markerChoice <- tclVar("")
    mm <- tktoplevel()
    tkwm.title(mm, "SIDAP: marker selection")
    scr <- tkscrollbar(mm, repeatinterval = 5, command = function(...) tkyview(tl, 
        ...))
    tl <- tklistbox(mm, height = 20, selectmode = "multiple", yscrollcommand = function(...) tkset(scr, 
        ...), background = "white")
    OnOK <- function() {
        tclvalue(markerChoice) <- markers[as.numeric(tkcurselection(tl)) + 
            1]
        tkdestroy(mm)
    }
    OK.but <- tkbutton(mm, text = " OK ", command = OnOK)
    tkgrid(tklabel(mm, text = "Please select your markers:"))
    tkgrid(tl, scr)
    tkgrid.configure(scr, rowspan = 4, sticky = "nsw")
    for (i in (1:length(markers))) {
        tkinsert(tl, "end", markers[i])
    }
    tkgrid(OK.but)
    tkwait.window(mm)
    
    # return parameters
    paras <- strsplit(tclvalue(markerChoice), " ", fixed = TRUE)[[1]]
    return(paras)
}
