add_col_to_fcs <-
function(analysisFile, rawFCSdir, analyzedFCSdir, transformed_col = c("ViSNE_V1", 
    "ViSNE_V2"), cluster_col = c("cluster")) {
    
    
    if (!require(flowCore)) {
        SIDAP_LoadPackageMsg()
    }
    
    lgcl <- logicleTransform(w = 0.1, t = 4000, m = 4.5, a = 0)
    ilgcl <- inverseLogicleTransform(trans = lgcl)
    
    data <- read.table(analysisFile, sep = "\t", row.names = 1, header = T)
    
    if (!file.exists(analyzedFCSdir)) {
        dir.create(analyzedFCSdir)
    }
    
    if (!is.null(transformed_col)) {
        transformed <- data[, transformed_col]
        row.has.na <- apply(transformed, 1, function(x) {
            any(is.na(x))
        })
        transformed <- transformed[!row.has.na, ]
        N_transformed <- apply(transformed, 2, function(x) ((x - min(x))/(max(x) - 
            min(x))) * 4.4)
        R_N_transformed <- apply(N_transformed, 2, ilgcl)
        row.names(R_N_transformed) <- row.names(transformed)
    }
    
    if (!is.null(cluster_col)) {
        if (exists("row.has.na")) {
            clust_cor_1 <- data[!row.has.na, cluster_col]%%10
            clust_cor_2 <- floor(data[!row.has.na, cluster_col]/10)
        } else {
            clust_cor_1 <- data[, cluster_col]%%10
            clust_cor_2 <- floor(data[, cluster_col]/10)
        }
        clust_cor_1 <- clust_cor_1 + runif(length(clust_cor_1), 0, 0.2)
        clust_cor_2 <- clust_cor_2 + runif(length(clust_cor_2), 0, 0.2)
        clust_cor <- cbind(clust_cor_1, clust_cor_2)
        N_clust_cor <- apply(clust_cor, 2, function(x) ((x - min(x))/(max(x) - 
            min(x))) * 4.4)
        R_N_clust_cor <- apply(N_clust_cor, 2, ilgcl)
        if (exists("row.has.na")) {
            row.names(R_N_clust_cor) <- row.names(data)[!row.has.na]
        } else {
            row.names(R_N_clust_cor) <- row.names(data)
        }
    }
    
    if ((!is.null(transformed_col)) && (!is.null(cluster_col))) {
        if (sum(row.names(R_N_transformed) != row.names(R_N_clust_cor)) == 
            0) {
            to_add <- cbind(R_N_transformed, R_N_clust_cor)
        } else {
            print("error:the row.names is not consistent between transformed coordinates and cluster.\n")
        }
    } else if (!is.null(transformed_col)) {
        to_add <- R_N_transformed
    } else if (!is.null(cluster_col)) {
        to_add <- R_N_clust_cor
    }
    
    sample <- unique(sub("_[0-9]*$", "", row.names(to_add)))
    
    for (i in 1:length(sample)) {
        if (grepl("+", sample[i])) {
            pattern <- sub("\\+", "\\\\+", sample[i])
        } else {
            pattern <- sample[i]
        }
        pattern <- paste(pattern, "_", sep = "")
        
        to_add_i <- to_add[grep(pattern, row.names(to_add)), ]
        cellNo_i <- as.integer(sub("^.*_", "", row.names(to_add_i)))
        
        fcs <- read.FCS(paste(rawFCSdir, "/", sample[i], ".fcs", sep = ""))
        temp <- fcs@exprs[cellNo_i, ]
        fcs@exprs <- temp
        
        newfcs <- cbind2(fcs, to_add_i)
        newfcs@parameters$desc <- c(fcs@parameters$desc, colnames(to_add_i))
        write.FCS(newfcs, paste(analyzedFCSdir, "/", sample[i], ".fcs", 
            sep = ""))
    }
}
