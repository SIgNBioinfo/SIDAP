DataDensityPlot <-
function(ydata, sig_tol) {
    
    # Makes a heat map of data density x, y - data x and y coordinates
    # levels - number of contours to show
    
    
    density_output <- DataDensity(ydata, 400, 400, sig_tol)  #Partitions the y-space into a 400 x 400 pixel grid. Change according to requirements
    
    density_output[[1]] <- density_output[[1]]/sum(density_output[[1]])
    
    
    density_output[[1]][density_output[[1]] < 5e-08] <- 0  # Remove noise
    
    return(density_output)
}
