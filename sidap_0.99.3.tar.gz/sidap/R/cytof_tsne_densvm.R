cytof_tsne_densvm <-
function(rawFCSdir = getwd(), fcsFile = NULL, resDir = getwd(), 
    baseName, mergeMethod = "ceil", fixedNum = 10000, lgclMethod = "fixed", 
    para = NULL, paraFile = "../parameter.txt", ifTransform = TRUE, transformMethod = "tsne", 
    ifCluster = TRUE) {
    
    if (any (c((!require(flowCore)), (!require(mclust)), (!require(gplots)),
              (!require(reshape)), (!require(graphics)), (!require(ggplot2)),
              (!require(e1071))))) {
        SIDAP_LoadPackageMsg()      
    }
    
    
    lgcl <- logicleTransform(w = 0.1, t = 4000, m = 4.5, a = 0)
    ilgcl <- inverseLogicleTransform(trans = lgcl)
    
    
    if (!file.exists("analyzedFCS")) {
        dir.create("analyzedFCS")
    }
    
    if (is.null(fcsFile)) {
        fcsFile <- list.files(path = rawFCSdir, pattern = ".fcs$", full.names = TRUE)
    }
    exprs <- fcs_lgcl_merge(fcsFile, lgclMethod, mergeMethod, fixedNum = fixedNum)
    if (is.null(para)) {
        para <- as.character(read.table(paraFile, sep = "\t", header = T)[, 1])
    }
    para <- sort(para)
    exprs <- exprs[, para]
    write.table(exprs, paste(resDir, "/", baseName, ".txt", sep = ""), 
        sep = "\t", col.names = NA)
    
    if (ifTransform) {
        transformed <- cytof_nonlinear(exprs, baseName = baseName, method = transformMethod)
        write.table(transformed, paste(baseName, "_tsne.txt", sep = ""), 
            sep = "\t", col.names = NA)
    }
    if (ifCluster) {
        cluster_output <- ACCENSE_cluster(transformed, exprs, para)
        
        train_data <- exprs[as.character(cluster_output[[3]]$ind), ]
        train_class <- cluster_output[[3]]$cluster
        # Subpop <- cluster_output[[2]] train_data <- data.frame()
        # train_class <- vector() for(i in 1:length(Subpop)){
        # if(is.null(dim(Subpop[[i]]$X))){ train_data <-
        # rbind(train_data,t(Subpop[[i]]$X)) }else{ train_data <-
        # rbind(train_data,Subpop[[i]]$X) } train_class <-
        # c(train_class,rep(i,Subpop[[i]]$size)) }
        svm.obj <- svm(train_data, train_class, type = "C-classification")
        pred <- predict(svm.obj, exprs)
        cluster <- data.frame(cluster = pred)
        if (sum(row.names(exprs) != row.names(cluster)) > 0) {
            print("Error.\n")
        }
        tsne_cluster <- data.frame(transformed, cluster)
        write.table(tsne_cluster, paste(baseName, "_tsne_cluster.txt", 
            sep = ""), sep = "\t", col.names = NA)
        
        add_col_to_fcs(analysisFile = paste(baseName, "_tsne_cluster.txt", 
            sep = ""), rawFCSdir = rawFCSdir, analyzedFCSdir = "analyzedFCS", 
            transformed_col = c("ViSNE_dim1", "ViSNE_dim2"), cluster_col = c("cluster"))
    } else {
        add_col_to_fcs(analysisFile = paste(baseName, "_tsne.txt", sep = ""), 
            rawFCSdir = rawFCSdir, analyzedFCSdir = "analyzedFCS", transformed_col = c("ViSNE_dim1", 
                "ViSNE_dim2"), cluster_col = NULL)
    }
    
    if (sum(row.names(exprs) != row.names(cluster)) > 0) {
        print("Error.\n")
    }
    exprs_cluster <- data.frame(exprs, cluster)
    clust_mean <- aggregate(. ~ cluster, data = exprs_cluster, mean)
    
    write.table(clust_mean, paste(baseName, "_clusterMean.txt", sep = ""), 
        sep = "\t", row.names = FALSE)
    rownames(clust_mean) <- paste("cluster_", clust_mean$cluster, sep = "")
    clust_mean <- clust_mean[, -which(colnames(clust_mean) == "cluster")]
    if (nrow(clust_mean) > 1 & ncol(clust_mean) > 1) {
        pdf(paste(baseName, "clusterMeanHeatmap.pdf", sep = ""))
        heatmap.2(as.matrix(clust_mean), col = bluered, trace = "none", 
            scale = "none", margins = c(8, 8))
        dev.off()
    }
    
    ##### calculate cluster percentage
    cluster$sample <- sub("_[0-9]*$", "", row.names(cluster))
    clust_cellCount <- as.data.frame(table(cluster[, c("sample", "cluster")]))
    colnames(clust_cellCount)[3] <- "cellCount"
    sample_cellCount <- as.data.frame(table(cluster$sample))
    colnames(sample_cellCount) <- c("sample", "totalCellCount")
    clust_cellCount <- merge(clust_cellCount, sample_cellCount, by = "sample")
    clust_cellCount$percentage <- clust_cellCount$cellCount/clust_cellCount$totalCellCount * 
        100
    write.table(clust_cellCount, paste(baseName, "_clusterCellCount.txt", 
        sep = ""), sep = "\t", row.names = FALSE)
    clust_percentage <- cast(clust_cellCount, sample ~ cluster, value = "percentage")
    write.table(clust_percentage, paste(baseName, "_clusterPerc.txt", 
        sep = ""), sep = "\t", row.names = FALSE)
    clust_percentage_long <- melt(clust_percentage, id = "sample", variable_name = "cluster")
    colnames(clust_percentage_long)[which(colnames(clust_percentage_long) == 
        "value")] <- "percentage"
    write.table(clust_percentage_long, paste(baseName, "_clusterPerc_long.txt", 
        sep = ""), sep = "\t", row.names = FALSE)
    
    row.names(clust_percentage) <- clust_percentage$sample
    clust_percentage <- clust_percentage[, -which(colnames(clust_percentage) == 
        "sample")]
    colnames(clust_percentage) <- paste("cluster_", colnames(clust_percentage), 
        sep = "")
    if(nrow(clust_percentage) > 1 && ncol(clust_percentage) > 1){
        pdf(paste(baseName,"clusterPercHeatmap.pdf",sep=""),width=nrow(clust_percentage)*0.8,height=ncol(clust_percentage)*0.8)
        heatmap.2(t(as.matrix(clust_percentage)),col=bluered,trace="none",scale="none",margins = c(15,8),labRow=colnames(clust_percentage),labCol=rownames(clust_percentage),cexRow=1,cexCol=1)
        dev.off()
     }
}
