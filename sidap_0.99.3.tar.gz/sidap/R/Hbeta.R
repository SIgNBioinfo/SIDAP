Hbeta <-
function(D, beta, P) {
    sumP <- sum(P)
    H <- log(sumP) + beta * sum(D * P)/sumP
    return(H)
}
