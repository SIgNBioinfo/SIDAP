PeakFind <-
function(img) {
    
    
    d <- img$z
    
    edg <- 6
    threshold <- max(c(min(apply(d, 1, max)), min(apply(t(d), 1, max))))
    
    # Apply threshold
    
    indicator <- (d > threshold) * 1  #Indicator matrix
    d <- d * indicator
    
    if (sum(d) != 0) {
        # If the image is still non-zero
        
        # Peak Find - Using the local maxima approach Skip the edge pixels
        
        rows_cols <- which(d[edg:(dim(d)[1] - edg), edg:(dim(d)[2] - 
            edg)] > 0, arr.ind = TRUE)
        x <- rows_cols[, 1]
        y <- rows_cols[, 2]
        cent <- c(0, 0)  #Initialize
        
        # Initialize outputs
        x <- x + edg - 1
        y <- y + edg - 1
        
        for (j in 1:length(y)) {
            
            if (d[x[j], y[j]] >= d[x[j] - 1, y[j] - 1] && d[x[j], y[j]] > 
                d[x[j] - 1, y[j]] && d[x[j], y[j]] >= d[x[j] - 1, y[j] + 
                1] && d[x[j], y[j]] > d[x[j], y[j] - 1] && d[x[j], y[j]] > 
                d[x[j], y[j] + 1] && d[x[j], y[j]] >= d[x[j] + 1, y[j] - 
                1] && d[x[j], y[j]] > d[x[j] + 1, y[j]] && d[x[j], y[j]] >= 
                d[x[j] + 1, y[j] + 1]) {
                cent <- rbind(cent, c(img$x[x[j], y[j]], img$y[x[j], 
                  y[j]]))
            }
            
        }
        
    }
    
    # Remove first row which is a dummy
    cent <- cent[-1, ]
    
    return(cent)
}
