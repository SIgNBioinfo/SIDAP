SIDAP_LoadPackageMsg <-
function() {
    msg <- "Could not load the dependent R package. Please run SIDAP_firstRun() to install it."
    stop(msg)
}
