DataDensity <-
function(ydata, width, height, sig_tol) {
    
    # Returns a density image of the data ydata - M x 2 vector containing
    # the y1-y2 coordinates of map-points width, height - width and
    # height of the map area in pixels sig_tol - kernel density function
    # variance (equal for x and y)
    
    limits <- matrix(0, 1, 4)
    limits[1] <- min(ydata[, 1]) - 5
    limits[2] <- max(ydata[, 1]) + 5
    limits[3] <- min(ydata[, 2]) - 5
    limits[4] <- max(ydata[, 2]) + 5
    
    deltax <- (limits[2] - limits[1])/width
    deltay <- (limits[4] - limits[3])/height
    
    dmap <- matrix(0, height, width)
    
    for (i in 0:(height - 1)) {
        yi <- limits[3] + i * deltay + deltay/2
        
        for (j in 0:(width - 1)) {
            xi <- limits[1] + j * deltax + deltax/2
            
            dist2 <- (ydata[, 1] - xi)^2 + (ydata[, 2] - yi)^2
            dd <- sum(exp(-dist2/(2 * sig_tol^2)))
            
            dmap[i + 1, j + 1] <- (1/sqrt(2 * pi * sig_tol^2)) * dd
        }
    }
    
    
    
    y2_range <- matrix(0, height, 1)
    for (i in 0:(height - 1)) {
        y2_range[i + 1] <- limits[3] + i * deltay + deltay/2
    }
    y2_range <- kronecker(matrix(1, 1, dim(dmap)[2]), y2_range)
    
    y1_range <- matrix(0, 1, width)
    for (i in 0:(width - 1)) {
        y1_range[i + 1] <- limits[1] + i * deltax + deltax/2
    }
    
    y1_range <- kronecker(matrix(1, dim(dmap)[1], 1), y1_range)
    
    return(list(z = dmap, x = y1_range, y = y2_range))
}
