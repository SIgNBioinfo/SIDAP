fcs_lgcl_merge <-
function(fcsFile, lgclMethod, mergeMethod, fixedNum = 10000) {
    names <- sub(".fcs", "", basename(fcsFile))
    if (mergeMethod == "all") {
        for (i in 1:length(fcsFile)) {
            exprs <- fcs_lgcl(fcsFile[i], lgclMethod)
            row.names(exprs) <- paste(names[i], 1:dim(exprs)[1], sep = "_")
            if (i < 2) {
                merged <- exprs
            } else {
                merged <- rbind(merged, exprs)
            }
        }
    } else if (mergeMethod == "min") {
        min <- 1e+09
        for (i in 1:length(fcsFile)) {
            exprs <- fcs_lgcl(fcsFile[i], lgclMethod)
            if (dim(exprs)[1] < min) {
                min <- dim(exprs)[1]
            }
        }
        for (i in 1:length(fcsFile)) {
            exprs <- fcs_lgcl(fcsFile[i], lgclMethod)
            row.names(exprs) <- paste(names[i], 1:dim(exprs)[1], sep = "_")
            v <- 1:dim(exprs)[1]
            s <- sample(v, min)
            exprs_s <- exprs[s, ]
            if (i < 2) {
                merged <- exprs_s
            } else {
                merged <- rbind(merged, exprs_s)
            }
        }
    } else if (mergeMethod == "fixed") {
        for (i in 1:length(fcsFile)) {
            exprs <- fcs_lgcl(fcsFile[i], lgclMethod)
            row.names(exprs) <- paste(names[i], 1:dim(exprs)[1], sep = "_")
            v <- 1:dim(exprs)[1]
            if (dim(exprs)[1] < fixedNum) {
                s <- sample(v, fixedNum, replace = TRUE)
            } else {
                s <- sample(v, fixedNum, replace = FALSE)
            }
            exprs_s <- exprs[s, ]
            if (i < 2) {
                merged <- exprs_s
            } else {
                merged <- rbind(merged, exprs_s)
            }
        }
    } else if (mergeMethod == "ceil") {
        for (i in 1:length(fcsFile)) {
            exprs <- fcs_lgcl(fcsFile[i], lgclMethod)
            row.names(exprs) <- paste(names[i], 1:dim(exprs)[1], sep = "_")
            v <- 1:dim(exprs)[1]
            if (dim(exprs)[1] <= fixedNum) {
                s <- v
            } else {
                s <- sample(v, fixedNum, replace = FALSE)
            }
            exprs_s <- exprs[s, ]
            if (i < 2) {
                merged <- exprs_s
            } else {
                merged <- rbind(merged, exprs_s)
            }
        }
    }
    return(merged)
}
