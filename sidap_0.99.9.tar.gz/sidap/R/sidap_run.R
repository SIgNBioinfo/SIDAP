#' sidap: an integrated analysis pipeline for mass cytometry data
#' 
#' This package is designed to facilitate the analysis workflow of mass cytometry data with 
#' automatic subset identification and population boundary detection. Both command line and 
#' a GUI are provided for runing the workflow easily.
#' 
#' This package integrates merge methods of multiple FCS files, dimension reduction (PCA, lle, t-SNE and ISOMAP) 
#' with density-based clustering (DensVM) for rapid subset detection. Subset-clustering scatter plot 
#' and heat map will be generated for objective comparative analysis and statistical testing. This workflow can be 
#' easily done using the main function \code{\link{cytof_tsne_densvm}} or a GUI for the main function 
#' \code{\link{cytof_tsne_densvm_GUI}}.
#' 
#' Pre-processing
#' 
#' Using function \code{\link{fcs_lgcl_merge}}, one or multiple FCS files were imported via the *read.FCS* 
#' function in the *flowCore* package. Then logicle transformation was applied to the expression value 
#' of selected markers of each FCS file. Auto logicle transformation and fixed logicle transformation 
#' are provided, then mutilple FCS files are merged using method \code{all}, \code{min}, \code{fixed} 
#' or \code{ceil}.
#' 
#' Dimensionality reduction
#' 
#' Using function \code{\link{cytof_dimReduction}}, t-Distributed Stochastic Neighbor Embedding (\code{tsne}) 
#' is suggested for dimensionality reduction although we also provide methods like \code{isomap}, 
#' \code{pca}, or \code{lle}.
#' 
#' Cluster analysis using DensVM
#' 
#' Density-based clustering aided by support Vector Machine (\code{\link{DensVM_cluster}}) are used to automate 
#' subset detection from the dimension-reducted map. By using DensVM, we are able to objectively assign every 
#' cell to an appropriate cluster.
#' 
#' Post-processing
#' 
#' Cluster results are annotated by using scatter plot and heatmap. Scatter plot visualize the cell points 
#' with colour indicating their assigned clusters and point shape representing their belonging samples
#' (\code{\link{cluster_plot}} and \code{\link{cluster_gridPlot}}). Cell events are also grouped by clusters 
#' and samples, and mean intensity values per cluster for every marker is calculated
#' (\code{\link{clust_mean_heatmap}} and \code{\link{clust_percentage_heatmap}}). 
#' Heat map visualizing the mean expression of every marker in every cluster is generated with no scaling on 
#' the row or column direction. Hierarchical clustering was generated using Euclidean distance and complete 
#' agglomeration method. We used the heat maps to interrogate marker expression to identify each cluster's 
#' defining markers. All intermediate files and the plots can be saved using the function \code{\link{cytof_write_resluts}}.
#' 
#' @examples
#' 
#' ## Run on GUI
#' #cytof_tsne_densvm_GUI()  # remove the hash symbol to launch the GUI
#' 
#' ## Run on command
#' dir <- system.file('extdata',package='sidap')
#' file <- list.files(dir, pattern='.fcs$', full=TRUE)
#' parameters <- list.files(dir, pattern='.txt$', full=TRUE)
#' ## remove the hash symbol to run the following command
#' #cytof_tsne_densvm(fcsFile = file, paraFile = parameters, rawFCSdir = dir, baseName = 'test')
#' 
#' ## Checking the vignettes for more details 
#' if(interactive()) browseVignettes(package = 'sidap')
#' 
#' @seealso \code{\link{cytof_tsne_densvm}}, \code{\link{cytof_tsne_densvm_GUI}}
#' @references \url{http://signbioinfo.github.io/SIDAP/}
#' @docType package
#' @name sidap
#' 
NULL


#' CyTOF data analysis for subpopulation detection 
#' 
#' \code{cytof_tsne_densvm} provides a workflow for one or multiple CyToF data analysis, 
#' including data preprocess with merging methods of multiple fcs file, logicle transformation, 
#' dimension reduction with PCA, lle, isomap or tsne(default), and a kernal-based local maxima 
#' clustering combined with SVM for subpopulation detection. The intermediate results can be saved 
#' into seperate files and the cluster results can be visualized in heatmaps and scatter plots.
#' 
#' @param rawFCSdir the directory that contains fcs files to be analysed.
#' @param fcsFile a vector containing names of fcs files to be analyzed. One or multiple fcs files are allowed.
#' @param resDir the directory where result files will be generated.
#' @param baseName a prefix that will be added to the names of result files.
#' @param comp Boolean tells if do compensation. This will be applied to flow cytometry data.
#' @param verbose Boolean.
#' @param mergeMethod when multiple fcs files are selected, cells can be combined using 
#' one of the four different methods including \code{ceil}, \code{all}, \code{min}, \code{fixed}. 
#' The default option is \code{ceil}, up to a fixed number (specified by \code{fixedNum}) of cells are sampled 
#' without replacement from each fcs file and combined for analysis.
#' \code{all}: all cells from each fcs file are combined for analysis. 
#' \code{min}: The minimum number of cells among all the selected fcs files are sampled from each fcs file and combined for analysis. 
#' \code{fixed}: a fixed num (specified by fixedNum) of cells are sampled (with replacement when the total number of cell is less than 
#' fixedNum) from each fcs file and combined for analysis.
#' @param fixedNum up to fixedNum of cells from each fcs file are used for analysis.
#' @param lgclMethod Logicle transformation method, either \code{auto} or \code{fixed}.
#' @param para the vector of selected makers. This can be provided in the \code{paraFile}.
#' @param paraFile a text file that specifies the list of makers to be used for analysis.
#' @param ifTransform a boolean to decide if dimensionality reduction will be performed. Default is TRUE.
#' @param transformMethod the method used for dimensionality reduction, including \code{tsne}, \code{pca}, \code{isomap}, and \code{lle}.
#' @param ifCluster a boolean to determine if cluster will be conducted.
#' @param writeResluts if save the results, and the post-processing results including scatter plot, heatmap, and statistical results.
#' @param ... more arguments contral the logicle transformation
#' @return a list containing \code{lgclMergedExprs}, \code{transData} and \code{clustersRes}. If choose 'writeResluts = TRUE', results will be saved into files under \code{resDir}
#' @author Chen Jinmiao 
#' @references \url{http://signbioinfo.github.io/SIDAP/}
#' @seealso \code{\link{sidap}}, \code{\link{cytof_tsne_densvm_GUI}}
#' @export
#' @examples
#' dir <- system.file('extdata',package='sidap')
#' file <- list.files(dir, pattern='.fcs$', full=TRUE)
#' parameters <- list.files(dir, pattern='.txt$', full=TRUE)
#' ## remove the hash symbol to run the following command
#' #cytof_tsne_densvm(fcsFile = file, paraFile = parameters, rawFCSdir = dir, baseName = 'test')   
cytof_tsne_densvm <- function(rawFCSdir = getwd(), fcsFile = NULL, 
    resDir = getwd(), baseName = "sidap_analysis", para = NULL, 
    paraFile = "./parameter.txt", comp = FALSE, verbose = FALSE, 
    lgclMethod = "fixed", mergeMethod = "ceil", fixedNum = 10000, 
    ifTransform = TRUE, transformMethod = "tsne", ifCluster = TRUE, 
    writeResluts = TRUE, ...) {
    
    ## get transformed, combined, marker-filtered fcs expression
    ## data
    if (is.null(fcsFile)) {
        fcsFile <- list.files(path = rawFCSdir, pattern = ".fcs$", 
            full.names = TRUE)
    }
    if (is.null(para)) {
        para <- as.character(read.table(paraFile, sep = "\t", 
            header = TRUE)[, 1])
    }
    para <- sort(para)
    exprs <- fcs_lgcl_merge(fcsFile, comp = FALSE, verbose = FALSE, 
        markers = para, lgclMethod = lgclMethod, mergeMethod = mergeMethod, 
        fixedNum = fixedNum, ...)
    
    ## dimension reduction
    transformed <- NULL
    if (ifTransform) {
        transformed <- cytof_dimReduction(exprs, method = transformMethod)
    }
    
    ## cluster
    cluster_output <- NULL
    if (ifCluster) {
        cluster_output <- DensVM_cluster(transformed, exprs)
    }
    
    ## write resluts
    analysis_resluts <- list(lgclMergedExprs = exprs, transData = transformed, 
        clustersRes = cluster_output)
    if (writeResluts == TRUE) {
        cytof_write_resluts(analysis_resluts, baseName, rawFCSdir, 
            resDir)
    } else {
        return(analysis_resluts)
    }
} 
