## ------------------------------------------------------------------------
require("sidap") 
# cytof_tsne_densvm_GUI()  ## remove the hash symbol to open the GUI

## ----, eval=FALSE--------------------------------------------------------
#  dir <- system.file('extdata',package='sidap')
#  file <- list.files(dir ,pattern='.fcs$', full=TRUE)
#  parameters <- list.files(dir, pattern='.txt$', full=TRUE)
#  # change "writeResluts" to TRUE for your analysis if you want to save the result files
#  cytof_tsne_densvm(fcsFile = file, paraFile = parameters, rawFCSdir = dir, baseName = 'test')

## ----, results='hide'----------------------------------------------------
?cytof_tsne_densvm

## ----, results='hide'----------------------------------------------------
?fcs_lgcl_merge

## ----, results='hide'----------------------------------------------------
?cytof_dimReduction

## ----, results='hide'----------------------------------------------------
?DensVM_cluster

## ----, results='hide'----------------------------------------------------
?cytof_write_resluts


