## ----, message=FALSE-----------------------------------------------------
require("sidap") 

## ----, results='hide'----------------------------------------------------
?sidap

## ------------------------------------------------------------------------
dir <- system.file('extdata',package='sidap')
files <- list.files(dir, pattern='.fcs$', full=TRUE)
paraFile <- list.files(dir, pattern='.txt$', full=TRUE)
parameters <- as.character(read.table(paraFile, sep = "\t", header = TRUE)[, 1])
#exprs <- fcs_lgcl_merge(fcsFile = files, markers = parameters, lgclMethod = "fixed", mergeMethod = "all")

## ----, results='hide'----------------------------------------------------
?cytof_dimReduction   ## check the help page
#transformed <- cytof_dimReduction(exprs, method = "tsne")

## ----, results='hide'----------------------------------------------------
?DensVM_cluster   ## check the help page
#clusterRes <- DensVM_cluster(transformed, exprs)

## ----, echo=FALSE--------------------------------------------------------
data <- list.files(dir, pattern='.RData$', full=TRUE)
load(data)

## ------------------------------------------------------------------------
clusters <- clusterRes[[2]]
head(clusters)

## ------------------------------------------------------------------------
cluster_plot(clusters, title = "Demo cluster", point_size = 2)

## ------------------------------------------------------------------------
exprs_cluster <- data.frame(exprs, cluster = clusters[, 3])
clust_statData <- clust_state(exprs_cluster, stat = "mean")
clust_mean_heatmap(clust_statData[[1]], baseName = "Demo")

