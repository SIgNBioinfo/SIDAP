#' @importFrom flowCore read.FCS logicleTransform estimateLogicle 
#' @importMethodsFrom flowCore transform

## merge multiple transformed expression datas from results fo "fcs_lgcl"
## return the merged exprs 
fcs_lgcl_merge <- function(fcsFile, lgclMethod, mergeMethod, fixedNum = 10000) {
        names <- sub(".fcs", "", basename(fcsFile))
        if (mergeMethod == "all") {
            for (i in 1:length(fcsFile)) {
                exprs <- fcs_lgcl(fcsFile[i], lgclMethod)
                row.names(exprs) <- paste(names[i], 1:dim(exprs)[1], sep = "_")
                if (i < 2) {
                    merged <- exprs
                } else {
                    merged <- rbind(merged, exprs)
                }
            }
        } else if (mergeMethod == "min") {
            min <- 1e+09
            for (i in 1:length(fcsFile)) {
                exprs <- fcs_lgcl(fcsFile[i], lgclMethod)
                if (dim(exprs)[1] < min) {
                    min <- dim(exprs)[1]
                }
            }
            for (i in 1:length(fcsFile)) {
                exprs <- fcs_lgcl(fcsFile[i], lgclMethod)
                row.names(exprs) <- paste(names[i], 1:dim(exprs)[1], sep = "_")
                v <- 1:dim(exprs)[1]
                s <- sample(v, min)
                exprs_s <- exprs[s, ]
                if (i < 2) {
                    merged <- exprs_s
                } else {
                    merged <- rbind(merged, exprs_s)
                }
            }
        } else if (mergeMethod == "fixed") {
            for (i in 1:length(fcsFile)) {
                exprs <- fcs_lgcl(fcsFile[i], lgclMethod)
                row.names(exprs) <- paste(names[i], 1:dim(exprs)[1], sep = "_")
                v <- 1:dim(exprs)[1]
                if (dim(exprs)[1] < fixedNum) {
                    s <- sample(v, fixedNum, replace = TRUE)
                } else {
                    s <- sample(v, fixedNum, replace = FALSE)
                }
                exprs_s <- exprs[s, ]
                if (i < 2) {
                    merged <- exprs_s
                } else {
                    merged <- rbind(merged, exprs_s)
                }
            }
        } else if (mergeMethod == "ceil") {
            for (i in 1:length(fcsFile)) {
                exprs <- fcs_lgcl(fcsFile[i], lgclMethod)
                row.names(exprs) <- paste(names[i], 1:dim(exprs)[1], sep = "_")
                v <- 1:dim(exprs)[1]
                if (dim(exprs)[1] <= fixedNum) {
                    s <- v
                } else {
                    s <- sample(v, fixedNum, replace = FALSE)
                }
                exprs_s <- exprs[s, ]
                if (i < 2) {
                    merged <- exprs_s
                } else {
                    merged <- rbind(merged, exprs_s)
                }
            }
        }
        return(merged)
    }


## read the FCS data and apply Logicle transformation
## return the transformed expression value with true col names
fcs_lgcl <- function(fcsFile, lgclMethod = "fixed") {
        
    fcs <- suppressWarnings(read.FCS(fcsFile))
    
    if (lgclMethod == "jm_auto") {
        ### jm_auto estimate the optimal parameters for logicle transform
        ### logicleTransform(w,t,m,a) m is the maximum of transformed data,
        ### m=4.5 is a option for most cases a: for a standard Logicle plot a =
        ### 0 t is the maximum of original data before transformation w =
        ### (m-log10(t/|r|))/2 r is the fifth percentile of all events that are
        ### below zero
        
        m = 4.5
        a = 0
        
        raw_exprs <- fcs@exprs
        exprs <- raw_exprs
        for (i in 1:ncol(raw_exprs)) {
            t <- max(raw_exprs[, i])
            neg_idx <- which(raw_exprs[, i] < 0)
            if (length(neg_idx) > 0) {
                neg <- raw_exprs[neg_idx, i]
                r <- quantile(neg, 0.05)
                w <- (m - log10(t/abs(r)))/2
            } else {
                r <- 0
                w <- 0
            }
            lgcl <- logicleTransform(w = w, t = t, m = m, a = a)
            exprs[, i] <- sapply(raw_exprs[, i], lgcl)
        }
        for (i in 1:nrow(fcs@parameters)) {
            if ((!is.na(fcs@parameters$desc[i])) && fcs@parameters$desc[i] != 
                " ") {
                colnames(exprs)[i] <- fcs@parameters$desc[i]
            } else {
                colnames(exprs)[i] <- fcs@parameters$name[i]
            }
        }
    } else if (lgclMethod == "auto") {
        lgcl <- estimateLogicle(fcs, channels = colnames(exprs(fcs)))
        lgcl_transformed <- transform(fcs, lgcl)
        exprs <- lgcl_transformed@exprs
        header <- lgcl_transformed@parameters@data[, c("name", "desc")]
        if (sum(colnames(exprs) != header$name) == 0) {
            colnames(exprs) <- header$desc
        }
    } else if (lgclMethod == "fixed") {
        lgcl <- logicleTransform(w = 0.1, t = 4000, m = 4.5, a = 0)
        exprs_raw <- fcs@exprs
        exprs <- apply(exprs_raw, 2, lgcl)
        
        for (i in 1:nrow(fcs@parameters)) {
            if ((!is.na(fcs@parameters$desc[i])) && fcs@parameters$desc[i] != 
                " ") {
                colnames(exprs)[i] <- fcs@parameters$desc[i]
            } else {
                colnames(exprs)[i] <- fcs@parameters$name[i]
            }
        }
    } else if (lgclMethod == "fixed_old") {
        lgcl <- logicleTransform(w = 0.25, t = 16409, m = 4.5, a = 0)
        exprs_raw <- fcs@exprs
        exprs <- apply(exprs_raw, 2, lgcl)
        
        for (i in 1:nrow(fcs@parameters)) {
            if ((!is.na(fcs@parameters$desc[i])) && fcs@parameters$desc[i] != 
                " ") {
                colnames(exprs)[i] <- fcs@parameters$desc[i]
            } else {
                colnames(exprs)[i] <- fcs@parameters$name[i]
            }
        }
    }
    return(exprs)
}