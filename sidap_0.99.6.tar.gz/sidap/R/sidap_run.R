#' cytof data analysis for subpopulation detection 
#' 
#' \code{cytof_tsne_densvm} provides a workflow for one of multiple CyToF data analysis, 
#' including data preprocess with multiple fcs file merge methods and logicle transformation, 
#' dimension reduction with PCA, lle, isomap and tsne(default), and a kernal-based local maxima 
#' cluster combined with SVM for subpopulation detection. The intermediate results are saved into
#' seperate files and the cluster results are presents in heatmaps.
#' 
#' @param rawFCSdir the directory that contains fcs files.
#' @param fcsFile fcs files to be analyzed. One or multiple fcs files are allowed.
#' @param resDir the directory where result files will be generated.
#' @param baseName a prefix that will be added to the names of result files.
#' @param mergeMethod hen multiple fcs files are selected, cells can be combined using one of the four different methods including ceil, all, min, fixed. The default option is ceil, up to a fixed number (specified by fixedNum) of cells are sampled without replacement from each fcs file and combined for analysis.all: all cells from each fcs file are combined for analysis. min: The minimum number of cells among all the selected fcs files are sampled from each fcs file and combined for analysis. fixed: a fixed num (specified by fixedNum) of cells are sampled (with replacement when the total number of cell is less than fixedNum) from each fcs file and combined for analysis.
#' @param fixedNum up to fixedNum of cells from each fcs file are used for analysis.
#' @param lgclMethod it is fixed to fixed.
#' @param para the vector of selected makers. 
#' @param paraFile a text file that specifies the list of makers to be used for analysis.
#' @param ifTransform a boolean to decide if dimensionality reduction will be performed. Default is TRUE.
#' @param transformMethod the method used for dimensionality reduction, including pca, isomap, tsne and lle.
#' @param ifCluster a boolean to determine if cluster will be conducted.
#' @return all intermediate results for each analysis step are saved into files under \code{resDir}
#' @author Chen Jinmiao 
#' @references \url{https://github.com/SIgNBioinfo/SIDAP}
#' @export
#' @importFrom flowCore read.FCS write.FCS inverseLogicleTransform logicleTransform
#' @importFrom e1071 svm
#' @importFrom gplots heatmap.2 bluered    
#' @importFrom ggplot2 ggplot ggsave aes facet_wrap geom_point geom_rug theme_bw theme xlab ylab ggtitle coord_fixed guides guide_legend scale_shape_manual
#' @importFrom reshape cast melt.data.frame
cytof_tsne_densvm <- function(rawFCSdir = getwd(), fcsFile = NULL, 
                              resDir = getwd(), baseName, mergeMethod = "ceil", 
                              fixedNum = 10000, lgclMethod = "fixed", 
                              para = NULL, paraFile = "./parameter.txt", 
                              ifTransform = TRUE, transformMethod = "tsne", 
                              ifCluster = TRUE) {
    
    ## get transformed, combined, marker-filtered fcs expression data and write to a file       
    if (is.null(fcsFile)) {
        fcsFile <- list.files(path = rawFCSdir, pattern = ".fcs$", full.names = TRUE)
    }
    exprs <- fcs_lgcl_merge(fcsFile, lgclMethod, mergeMethod, fixedNum = fixedNum)
    
    if (is.null(para)) {
        para <- as.character(read.table(paraFile, sep = "\t", header = T)[, 1])
    }
    para <- sort(para)
    
    if (any (!(para %in% colnames(exprs)))){
        stop("\n The input parameters contain channels which are not in the FCS file(s), 
             please check your parameters! \n")
    }
    exprs <- exprs[ ,para]
    
    setwd(resDir)
    write.table(exprs, paste(baseName, "_lgcl_merged_markerFiltered_exprsData.txt", sep = ""), 
                sep = "\t", col.names = NA)   
    
    ## dimension reduction
    if (ifTransform) {
        transformed <- cytof_dimReduction(exprs, baseName = baseName, method = transformMethod)
        write.table(transformed, paste(baseName, "_transformed.txt", sep = ""), 
                    sep = "\t", col.names = NA)
    }
    
    ## cluster and plot, write cluster results back to each fcs file
    if (ifCluster) {
        # kernal based local maxima cluster
        trans_col_names <- colnames(transformed)
        cluster_output <- DensVM_cluster(baseName, transformed, exprs, para)
        
        ## SVM prediction using the tsne cluster results
        train_data <- exprs[as.character(cluster_output[[3]]$ind),]
        train_class <- cluster_output[[3]]$cluster
        svm.obj <- svm(train_data,train_class,type="C-classification")
        pred <- predict(svm.obj,exprs)
        cluster <- data.frame(cluster=pred)
        
        
        if (sum(row.names(exprs) != row.names(cluster)) > 0) print("Cluster Error!.\n")
        tsne_cluster <- data.frame(transformed, cluster)
        
        # save the cluster results and add cluster tag to each fcs file
        write.table(tsne_cluster, paste(baseName, "tsne_cluster.txt", sep = "_"), sep = "\t", col.names = NA)
        
        suppressWarnings(add_col_to_fcs(analysisFile = paste(baseName, "tsne_cluster.txt", sep = "_"), 
                                        rawFCSdir = rawFCSdir, analyzedFCSdir = paste(baseName, "analyzedFCS", sep = "_"), 
                                        transformed_col = trans_col_names, cluster_col = c("cluster")))
        
        # plot the cluster results with cluster labels
        tsne_cluster$sample <- sub("_[0-9]*$", "", row.names(tsne_cluster))
        m <- regexpr("_[0-9]*$", row.names(tsne_cluster))
        tsne_cluster$sample_ID <- substring(regmatches(row.names(tsne_cluster), m), 2)
        tsne_cluster$cluster <- as.factor(tsne_cluster$cluster)
        
        col_legend_row <- ceiling(length(unique(tsne_cluster$cluster)) / 15)
        size_legend_row <- ceiling(length(unique(tsne_cluster$sample)) / 4)
        grid_row_num <- size_legend_row
        if (length(unique(tsne_cluster$sample)) >= 4){
            grid_col_num <- 4
        } else {
            grid_col_num <- length(unique(tsne_cluster$sample))
        }       
        grid_size <- sqrt(225 / (grid_row_num * grid_col_num))
        grid_width <- grid_size * grid_col_num
        grid_height <- grid_size * grid_row_num
        
        cluster_plot <- ggplot(tsne_cluster, aes(x = tsne_1, y = tsne_2, colour = cluster, shape = sample)) + 
            geom_point(size = 1) + geom_rug(position="jitter", size=.2) + theme_bw() +
            scale_shape_manual(values=LETTERS[1:length(unique(tsne_cluster$sample))]) +
            theme(legend.position = "bottom") + xlab("tsne_1") + ylab("tsne_2") + 
            ggtitle("TSNE cluster plot") + coord_fixed() +
            guides(colour = guide_legend(nrow = col_legend_row), 
                   shape = guide_legend(nrow = size_legend_row))
        ggsave(filename = paste(baseName, "tsne_cluster_plot.pdf", sep = "_"), 
               cluster_plot, width = 13, height = 13)
        graphics.off()
        
        if (length(fcsFile) > 1){
            cluster_grid_plot <- ggplot(tsne_cluster, aes(x = tsne_1, y = tsne_2, colour = cluster)) + 
                facet_wrap( ~ sample, ncol=4, scales="free") +
                geom_point(size = 0.7) + geom_rug(position="jitter", size=.2) + theme_bw() + 
                theme(legend.position = "bottom") + xlab("tsne_1") + ylab("tsne_2") + 
                ggtitle("TSNE cluster grid plot") + coord_fixed() +
                guides(colour = guide_legend(nrow = col_legend_row), 
                       shape = guide_legend(nrow = size_legend_row))
            ggsave(filename = paste(baseName, "tsne_cluster_grid_plot.pdf", sep = "_"),
                   cluster_grid_plot, width = grid_width, height = grid_height)
            graphics.off()
        }
        
        # plot the cluster mean heatmap
        exprs_cluster <- data.frame(exprs, cluster)
        clust_mean <- aggregate(. ~ cluster, data = exprs_cluster, mean)
        
        write.table(clust_mean, paste(baseName, "clusterMean.txt", sep = "_"), 
                    sep = "\t", row.names = FALSE)
        rownames(clust_mean) <- paste("cluster_", clust_mean$cluster, sep = "")
        clust_mean <- clust_mean[, -which(colnames(clust_mean) == "cluster")]
        if (nrow(clust_mean) > 1 & ncol(clust_mean) > 1) {
            cex_row_label <- (9 - ceiling(nrow(clust_mean) / 10)) / 10 
            cex_col_label <- (9 - ceiling(ncol(clust_mean) / 10)) / 10
            pdf(paste(baseName, "clusterMeanHeatmap.pdf", sep = "_"))
            par(cex.main=0.8)
            heatmap.2(as.matrix(clust_mean), col = bluered, trace = "none", 
                      scale = "none", cexRow=cex_row_label, cexCol=cex_col_label, srtCol=30,
                      main = paste(baseName, "\n clusterMean heatmap", sep = " "))
            dev.off()
        }
        
        # calculate and plot cluster percentage
        cluster$sample <- sub("_[0-9]*$", "", row.names(cluster))
        clust_cellCount <- as.data.frame(table(cluster[, c("sample", "cluster")]))
        colnames(clust_cellCount)[3] <- "cellCount"
        sample_cellCount <- as.data.frame(table(cluster$sample))
        colnames(sample_cellCount) <- c("sample", "totalCellCount")
        clust_cellCount <- merge(clust_cellCount, sample_cellCount, by = "sample")
        clust_cellCount$percentage <- clust_cellCount$cellCount/clust_cellCount$totalCellCount * 100
        write.table(clust_cellCount, paste(baseName, "_clusterCellCount.txt", sep = ""), 
                    sep = "\t", row.names = FALSE)
        clust_percentage <- cast(clust_cellCount, sample ~ cluster, value = "percentage")
        write.table(clust_percentage, paste(baseName, "_clusterPerc.txt", sep = ""), 
                    sep = "\t", row.names = FALSE)
        clust_percentage_long <- melt.data.frame(clust_percentage, id.vars = "sample", variable_name = "cluster")
        colnames(clust_percentage_long)[which(colnames(clust_percentage_long) == "value")] <- "percentage"
        write.table(clust_percentage_long, paste(baseName, "_clusterPerc_long.txt", sep = ""), 
                    sep = "\t", row.names = FALSE)
        
        row.names(clust_percentage) <- clust_percentage$sample
        clust_percentage <- clust_percentage[, -which(colnames(clust_percentage) == "sample")]
        colnames(clust_percentage) <- paste("cluster_", colnames(clust_percentage), sep = "")
        if(nrow(clust_percentage) > 1 && ncol(clust_percentage) > 1){
            cex_row_label <- (9 - ceiling(ncol(clust_percentage) / 10)) / 10 
            cex_col_label <- (8 - ceiling(nrow(clust_percentage) / 10)) / 10
            pdf(paste(baseName,"clusterPercHeatmap.pdf",sep="_"))
            par(mar = rep(2, 4), cex.main=0.7)
            heatmap.2(t(as.matrix(clust_percentage)),col=bluered,trace="none", scale="none", 
                      labRow=colnames(clust_percentage), labCol=rownames(clust_percentage),
                      cexRow=cex_row_label, cexCol=cex_col_label, srtCol=30,
                      main = paste(baseName, "\n clusterPerc heatmap", sep = " "))
            dev.off()
        }
        
    } else {
        suppressWarnings(add_col_to_fcs(analysisFile = paste(baseName, "_tsne.txt", sep = ""), 
                                        rawFCSdir = rawFCSdir, analyzedFCSdir = "analyzedFCS", 
                                        transformed_col = c("X1", "X2"), cluster_col = NULL))   
    }
    }


add_col_to_fcs <- function(analysisFile, rawFCSdir, analyzedFCSdir, 
                           transformed_col = c("ViSNE_V1", "ViSNE_V2"), 
                           cluster_col = c("cluster")) {
    
    lgcl <- logicleTransform(w = 0.1, t = 4000, m = 4.5, a = 0)
    ilgcl <- inverseLogicleTransform(trans = lgcl)
    
    data <- read.table(analysisFile, sep = "\t", row.names = 1, header = T)
    
    if (!file.exists(analyzedFCSdir)) {
        dir.create(analyzedFCSdir)
    }
    
    if (!is.null(transformed_col)) {
        transformed <- data[, transformed_col]
        row.has.na <- apply(transformed, 1, function(x) {any(is.na(x))})
        transformed <- transformed[!row.has.na, ]
        N_transformed <- apply(transformed, 2, function(x) ((x - min(x))/(max(x) - min(x))) * 4.4)
        R_N_transformed <- apply(N_transformed, 2, ilgcl)
        row.names(R_N_transformed) <- row.names(transformed)
    }
    
    if (!is.null(cluster_col)) {
        if (exists("row.has.na")) {
            clust_cor_1 <- data[!row.has.na, cluster_col]%%10
            clust_cor_2 <- floor(data[!row.has.na, cluster_col]/10)
        } else {
            clust_cor_1 <- data[, cluster_col]%%10
            clust_cor_2 <- floor(data[, cluster_col]/10)
        }
        clust_cor_1 <- clust_cor_1 + runif(length(clust_cor_1), 0, 0.2)
        clust_cor_2 <- clust_cor_2 + runif(length(clust_cor_2), 0, 0.2)
        clust_cor <- cbind(clust_cor_1, clust_cor_2)
        N_clust_cor <- apply(clust_cor, 2, function(x) ((x - min(x))/(max(x) - min(x))) * 4.4)
        R_N_clust_cor <- apply(N_clust_cor, 2, ilgcl)
        if (exists("row.has.na")) {
            row.names(R_N_clust_cor) <- row.names(data)[!row.has.na]
        } else {
            row.names(R_N_clust_cor) <- row.names(data)
        }
    }
    
    if ((!is.null(transformed_col)) && (!is.null(cluster_col))) {
        if (sum(row.names(R_N_transformed) != row.names(R_N_clust_cor)) == 0) {
            to_add <- cbind(R_N_transformed, R_N_clust_cor)
        } else {
            print("error:the row.names is not consistent between transformed coordinates and cluster.\n")
        }
    } else if (!is.null(transformed_col)) {
        to_add <- R_N_transformed
    } else if (!is.null(cluster_col)) {
        to_add <- R_N_clust_cor
    }
    
    sample <- unique(sub("_[0-9]*$", "", row.names(to_add)))
    
    for (i in 1:length(sample)) {
        if (grepl("+", sample[i])) {
            pattern <- sub("\\+", "\\\\+", sample[i])
        } else {
            pattern <- sample[i]
        }
        pattern <- paste(pattern, "_", sep = "")
        
        to_add_i <- to_add[grep(pattern, row.names(to_add)), ]
        cellNo_i <- as.integer(sub("^.*_", "", row.names(to_add_i)))
        
        fcs <- suppressWarnings(read.FCS(paste(rawFCSdir, "/", sample[i], ".fcs", sep = "")))
        temp <- fcs@exprs[cellNo_i, ]
        fcs@exprs <- temp
        
        newfcs <- cbind2(fcs, to_add_i)
        newfcs@parameters$desc <- c(fcs@parameters$desc, colnames(to_add_i))
        suppressWarnings(write.FCS(newfcs, paste(analyzedFCSdir, "/", sample[i], ".fcs", sep = "")))
    }
}