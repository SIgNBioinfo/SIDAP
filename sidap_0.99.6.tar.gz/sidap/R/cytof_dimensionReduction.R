#' @importFrom lle lle
#' @importFrom vegan vegdist spantree isomap
#' @importFrom Rtsne Rtsne
#' @import stats

cytof_dimReduction <-
function(data, baseName = NULL, distMethod = "euclidean", 
    method = "isomap", lle_k = 12, lle_m = 2, isomap_k = 5, isomap_ndim = NULL, 
    isomapFragmentOK = FALSE) {
    if (is.null(isomap_ndim)) {
        isomap_ndim <- dim(data)[2]
    }
    if (method == "pca") {
        pca <- prcomp(data, scale = TRUE)
        pdf(paste(baseName, "pca_variance.pdf", sep = ""), width = 20, 
            height = 20)
        plot(pca, main = "Explained variance of principle components")
        dev.off()
        pdf(paste(baseName, "pca.pdf", sep = ""), width = 20, height = 20)
        plot(pca$x[, 1], pca$x[, 2], main = "sample PCA")
        dev.off()
        write.table(pca$x, paste(baseName, "pca_pc.txt", sep = ""), sep = "\t")
        colnames(pca$x) <- paste("PCA_dim", c(1:ncol(pca$x)), sep = "")
        return(pca$x)
    }
    if (method == "lle") {
        
        results <- lle(X = data, m = lle_m, k = lle_k, reg = 2, ss = FALSE, 
            id = TRUE, v = 0.9)
        png("lle.png")
        split.screen(c(2, 1))
        screen(1)
        plot(results$Y, main = "embedded data", xlab = expression(y[1]), 
            ylab = expression(y[2]))
        screen(2)
        plot(results$id, main = "intrinsic dimension", type = "l", xlab = expression(x[i]), 
            ylab = "id", lwd = 2)
        dev.off()
        write.table(results$Y, "lle_y.txt", sep = "\t")
        write.table(results$id, "lle_id.txt", sep = "\t")
    }
    if (method == "isomap") {        
        dis <- vegdist(data, method = distMethod)
        tr <- spantree(dis)
        ord <- isomap(dis, ndim = isomap_ndim, k = isomap_k, fragmentedOK = isomapFragmentOK)
        save(dis, tr, ord, file = paste(baseName, distMethod, isomap_k, 
            "isomap.RData", sep = ""))
        
        colnames(ord$points) <- paste("ISOMAP_dim", c(1:isomap_ndim), sep = "")
        write.table(ord$points, paste(baseName, "isomap.txt", sep = ""), sep = "\t", col.names = NA)
        
        pdf(paste(baseName, distMethod, isomap_k, "isomap.pdf", sep = "_"), 
            width = 35, height = 20)
        plot(ord, main = paste("isomap k=", isomap_k, sep = ""))
        dev.off()
        
        return(ord$points)
    }
    if (method == "tsne") {      
        tsne_out <- Rtsne(as.matrix(data), initial_dims = dim(as.matrix(data))[2],
                          dims = 2, perplexity = 30, theta = 0.5, 
                          check_duplicates = FALSE, pca = TRUE)
        
        mapped <- tsne_out$Y
        colnames(mapped) <- paste("tsne", c(1:ncol(mapped)), sep="_")
        rownames(mapped) <- row.names(data)
        
        pdf(paste(baseName, "tsne.pdf", sep = "_"), width = 35, height = 20)
        plot(mapped[, 1], mapped[, 2], main = "TSNE", xlab = "tsne_1", ylab = "tsne_2")
        dev.off()
        
        write.table(mapped, paste(baseName, "tsne.txt", sep = "_"), sep = "\t")
        return(mapped)
    }
}

