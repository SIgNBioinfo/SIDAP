## ----, eval=FALSE--------------------------------------------------------
#  cytof_tsne_densvm(rawFCSdir = "fcs file path", baseName = "a prefix appears on the output files names"

## ----, eval=FALSE--------------------------------------------------------
#  ?cytof_tsne_densvm()

## ----, eval=FALSE--------------------------------------------------------
#  cytof_tsne_densvm_GUI()

